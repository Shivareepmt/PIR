/* This is a Cfunctions (version 0.24) generated header file.
   Cfunctions is a free program for extracting headers from C files.
   Get Cfunctions from `http://www.hayamasa.demon.co.uk/cfunctions'. */

/* This file was generated with:
`cfunctions -i main.c'
*/
#ifndef CFH_MAIN_H
#define CFH_MAIN_H

/* From `main.c': */
int game_use_file (strid_t file );
void glk_main (void);

#endif /* CFH_MAIN_H */
