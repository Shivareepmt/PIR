/* This is a Cfunctions (version 0.24) generated header file.
   Cfunctions is a free program for extracting headers from C files.
   Get Cfunctions from `http://www.hayamasa.demon.co.uk/cfunctions'. */

/* This file was generated with:
`cfunctions -i no_snd.c' */
#ifndef CFH_NO_SND_H
#define CFH_NO_SND_H

/* From `no_snd.c': */
void init_sound (void);
void kill_sound (void);
void op_sound_effect (void);
void check_sound (event_t unused );

#endif /* CFH_NO_SND_H */
