// Automatically generated file -- do not edit!
#define GIT_MAJOR 1
#define GIT_MINOR 2
#define GIT_PATCH 8
