/*
 *   Give Turbo C a non-default stack length 
 */
#ifdef __TURBOC__
unsigned _stklen = 40000;
#endif /* __TURBOC__ */

